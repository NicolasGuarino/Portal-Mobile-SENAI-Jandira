﻿

<?php

	echo "Hello amazon - informática";

?>
